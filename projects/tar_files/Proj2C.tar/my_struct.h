/* This file should contain your struct definitions for Circle, Triangle, and 
   Rectangle */
