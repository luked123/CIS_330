/* This file should contain the 9 functions defined in prototypes.h */

#include <prototypes.h>
